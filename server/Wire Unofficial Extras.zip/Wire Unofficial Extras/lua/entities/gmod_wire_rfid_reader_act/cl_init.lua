
include('shared.lua')

ENT.RenderGroup 		= RENDERGROUP_BOTH