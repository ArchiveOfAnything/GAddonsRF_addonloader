ENT.Type = "anim"
ENT.Base = "base_wdr_entity"
ENT.PrintName = "Large Drum Antenna"