
ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"

ENT.PrintName			= "Buoyancy Controller"
ENT.Author				= "RabidToaster"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
