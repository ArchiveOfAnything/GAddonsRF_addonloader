

ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"

ENT.PrintName		= ""
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false




function ENT:SetEffect( name )
	self:SetNetworkedString( "Effect", name )
end

function ENT:GetEffect( name )
	return self:GetNetworkedString( "Effect" )
end


function ENT:SetOn( boolon )
	self:SetNetworkedBool( "On", boolon, true )
end

function ENT:IsOn( name )
	return self:GetNetworkedBool( "On" )
end

function ENT:SetOffset( v )
	self:SetNetworkedVector( "Offset", v, true )
end

function ENT:GetOffset( name )
	return self:GetNetworkedVector( "Offset" )
end

function ENT:SetPointing(value)
	self:SetNetworkedFloat( "Pointing", value )
end

function ENT:GetPointing()
	return self:GetNetworkedSFloat( "Pointing" )
end
