ENT.Type = "anim"
ENT.Base = "base_wdr_entity"
ENT.PrintName = "Squarial Phased Array Antenna"