ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"


ENT.PrintName			= ""
ENT.Author			= ""

ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions		= ""
ENT.Category			= ""

ENT.AdminSpawnable		= false
ENT.SpawnAble			= false
