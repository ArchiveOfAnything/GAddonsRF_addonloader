 	
ENT.Type 		= "anim"
ENT.Base 		= "base_wire_entity"

ENT.PrintName	= ""
ENT.Author		= ""
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
