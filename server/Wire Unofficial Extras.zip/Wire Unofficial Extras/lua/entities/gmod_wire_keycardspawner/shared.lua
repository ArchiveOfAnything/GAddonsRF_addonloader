ENT.Type 		= "anim"
ENT.Base 		= "base_wire_entity"

ENT.PrintName	= "Keycard Spawner (Wire)"
ENT.Author		= "Jesse Dubay (adb)"
ENT.Contact		= "jesse@thefortytwo.net"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
