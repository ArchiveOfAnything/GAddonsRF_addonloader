ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"

ENT.PrintName		= "PID Controller"
ENT.Author			= "Moyer"
ENT.Contact			= "Nope"
ENT.Purpose			= "Has no purpose"
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
