ENT.Type 		= "anim"
ENT.Base 		= "base_wire_entity"

ENT.PrintName	= "Proximity RAM-Card Base"
ENT.Author		= "Free Fall"
ENT.Contact		= ""
ENT.Information	= "Base for Proximity RAM-Card's"
ENT.Category	= "RAM-Cards (Wire)"

ENT.Spawnable = false
ENT.AdminSpawnable = false
