// setup.
ENT.Type 		= "anim";
ENT.Base 		= "base_wire_entity";
ENT.PrintName		= "Holographic Emitter";
ENT.Author		= "Chad 'Jinto'";
ENT.Contact		= "cdbarrett@gmail.com";
ENT.Spawnable		= false;
ENT.AdminSpawnable	= false;
ENT.RenderGroup 	= RENDERGROUP_BOTH;

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
