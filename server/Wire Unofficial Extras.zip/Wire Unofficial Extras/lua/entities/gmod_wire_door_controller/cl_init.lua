include("shared.lua")

ENT.Spawnable			= false
ENT.AdminSpawnable		= false