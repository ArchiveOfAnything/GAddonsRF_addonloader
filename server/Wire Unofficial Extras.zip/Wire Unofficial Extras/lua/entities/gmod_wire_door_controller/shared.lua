ENT.Type        	= "anim"
ENT.Base        	= "base_wire_entity"

ENT.PrintName   	= "Wire Door Controller"
ENT.Author      	= "Pennerlord"
ENT.Contact     	= ""
ENT.Purpose         = ""
ENT.Instructions    = ""