ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"


ENT.PrintName			= "Damage Scale"
ENT.Author			= "Hitman"

ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions		= ""
ENT.Category			= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

