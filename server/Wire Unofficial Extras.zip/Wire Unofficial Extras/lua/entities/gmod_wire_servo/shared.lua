

ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"

ENT.PrintName		= "Wired Servo"
ENT.Author			= "Exitlights (most code by tad2020)"
ENT.Contact			= ""
ENT.Purpose			= "support wire input"
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false


