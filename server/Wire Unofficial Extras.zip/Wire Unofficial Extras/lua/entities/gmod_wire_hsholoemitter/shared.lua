ENT.Type 		= "anim"
ENT.Base 		= "base_wire_entity"

ENT.PrintName	= "High Speed Holoemitter"
ENT.Author		= "Fizyk"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

