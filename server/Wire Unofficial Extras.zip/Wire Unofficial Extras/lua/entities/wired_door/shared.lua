ENT.Type 		= "anim"
ENT.Base = "base_wire_entity"

ENT.PrintName	= "Door"
ENT.Author		= "Doridian"
ENT.Contact		= "kontakt@doridian.de"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
