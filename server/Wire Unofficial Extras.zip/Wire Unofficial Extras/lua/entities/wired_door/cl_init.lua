
ENT.Spawnable			= false
ENT.AdminSpawnable		= false

include('shared.lua')

language.Add( "wired_door", "Door with Wire" )