ENT.Type 		= "anim"
ENT.Base 		= "gmod_wire_ramcard_defaultbase"

ENT.PrintName	= "Default (128KB)"
ENT.Author		= "Free Fall"
ENT.Contact		= ""
ENT.Information	= "The Default RAM-Card"
ENT.Category	= "RAM-Cards (Wire)"

ENT.Spawnable = true
ENT.AdminSpawnable = true
