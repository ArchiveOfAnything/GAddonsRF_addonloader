ENT.Type = "anim"
ENT.Base = "base_wdr_entity"
ENT.PrintName = "Satellite Uplink Dish"