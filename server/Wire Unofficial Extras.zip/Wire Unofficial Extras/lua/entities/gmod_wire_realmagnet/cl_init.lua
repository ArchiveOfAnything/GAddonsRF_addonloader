include('shared.lua')

function ENT:Draw()
	self.BaseClass.Draw(self)
	
end
