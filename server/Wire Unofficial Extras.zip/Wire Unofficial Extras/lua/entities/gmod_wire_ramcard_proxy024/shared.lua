ENT.Type 		= "anim"
ENT.Base 		= "gmod_wire_ramcard_proxybase"

ENT.PrintName	= "Proxy (24 Values / 100U)"
ENT.Author		= "Free Fall"
ENT.Contact		= ""
ENT.Information	= "A Proxy RAM-Card"
ENT.Category	= "RAM-Cards (Wire)"

ENT.Spawnable = true
ENT.AdminSpawnable = true
