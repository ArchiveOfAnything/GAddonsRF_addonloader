/*******************************
	Dynamic Memory Gate
	  for Wiremod
	  
	(C) Sebastian J.
********************************/

ENT.Type 			= "anim"
ENT.Base 			= "base_wire_entity"

ENT.PrintName		= "Dynamic Memory Gate"
ENT.Author			= "Borsty"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
