NOTICE: The github repository (https://github.com/wiremod/wire-extras/) is the only supported source for obtaining the unofficial wire-extras by the wiremod team. Any other sources, including the steam workshop, are not our responisbility. Due to licensing issues, there are currently no plans to put the unofficial wire extras repository on the steam workshop. This may change in the future, and if it does, this notice will be updated or removed.

All programs released in this Wire Extras SVN are released under the GPL v3, or their respective licenses. Please review License.txt for terms and conditions.

-----------------

Addons listed in this format:

Addon Contributed - developer - license (if not GPL v3)
URL

-----------------

Wire Touch Plate - Asphid_Jackal / TomyLobo
http://www.wiremod.com/forum/ideas-suggestions/16284-pressure-pad-3.html#post158700 (Asphid_Jackal's original release)

Adv. HUD Indicator - Moggie100 (Based on the origional by TheApathetic)
http://www.wiremod.com/forum/wiremod-addons/6571-advanced-hud-tools.html

Borsty's Wire Ents -
http://www.wiremod.com/forum/wiremod-addons/6888-wire-highspeed-ranger-2.html
	Dynamic Memory
	Wire Highspeed ranger

Buoyancy Stool - RabidToaster
http://forums.facepunchstudios.com/showthread.php?p=10186318

Door Stool - Doridian
http://forums.facepunchstudios.com/showthread.php?t=480569

DuFace's Gates
http://www.wiremod.com/forum/wiremod-addons/5661-entity-gates-vector-gates-other-stuff.html

Facer - Incompatible
http://www.garrysmod.org/downloads/?a=view&id=20074

Freezer - Incompatible
http://www.wiremod.com/forum/wiremod-addons/2352-wire-freezer.html

Free Fall's Extentions
http://www.wiremod.com/forum/wiremod-addons/5129-free-fall-extension-wire-socket-radio-other-stuff-i-made.html
	Adv. Dupe. Teleporter
	Adv. Dupe RAM-Chip
	Interactive Holoemitter
	String Switch Gate
	RAM-Card's

High-speed holoemitter - Fizyk
http://www.wiremod.com/forum/wiremod-addons/8308-high-speed-holoemitter.html

Insanely Huge Memory and Phi Gate - MagnetoHydroDynamics
http://www.wiremod.com/forum/wiremod-addons/5018-insanely-huge-memory-chips-phi-gate.html/

_Kilburn's Addons
http://www.wiremod.com/forum/wiremod-addons/4294-addons-wire-mod-mods-wire-addon.html
	Wire Materializer
	Wire Painter
	Wire Motor
	Wire Microphone
	Wire RFID Systems (http://www.wiremod.com/forum/wiremod-addons/3017-wire-rfid-systems.html)

Keycards - adb
http://www.wiremod.com/forum/wiremod-addons/2143-wire-keycards.html - (Placed in public domain by Author)

Keypad - Robbis_1 and TomyLobo
http://facepunch.com/threads/276931

Lever - cpf
http://www.wiremod.com/forum/wiremod-addons/4097-wire-lever.html

Multi-wire tool - Incompatible
http://www.wiremod.com/forum/wiremod-addons/2545-multi-wire-tool.html

No Collide Addon - splat2010
http://www.wiremod.com/forum/wiremod-addons/4777-no-collide-addon.html

PID Controller (super delta) - Moyer
http://www.wiremod.com/forum/wiremod-addons/5061-pid-controller.html

Prop Core - Mr.Faul
http://wiki.garrysmod.com/?title=Expression_2_-_Prop_Core

Servo 2 - Exitlights
http://www.wiremod.com/forum/wiremod-addons/6878-wired-servo-2-a.html

Semi-realistic Wiremod Magnet - cpf
http://www.wiremod.com/forum/wiremod-addons/7693-semi-realistic-wiremod-magnet.html

Simple Servo - Selig
http://www.wiremod.com/forum/wiremod-addons/5850-wire-simple-servo.html

Simulate Data Stool - ZeitJT
http://www.wiremod.com/forum/wiremod-addons/8135-simulate-data-stool.html

Wired Damage Scale - Hitman271
http://www.wiremod.com/forum/wiremod-addons/6346-wired-damage-scale.html

Wire Directional Radio Kit - philxyz
http://www.wiremod.com/forum/wiremod-addons-coding/525-wire-directional-radios.html

Wired Npcs - Hitman271
http://www.wiremod.com/forum/wiremod-addons/5930-wired-npc.html

Wired Wirer - Jeremydeath
http://www.wiremod.com/forum/wiremod-addons/9941-jeremydeaths-various-wire-addons.html

Wire Wireless - AlgorithmX2
http://www.wiremod.com/forum/wiremod-addons/6471-wire-wireless.html

Wire Field Generators - AlgorithmX2
http://www.wiremod.com/forum/wiremod-addons/6497-wire-field-generator-s.html

XYZ Beacon - Doticatto
http://www.wiremod.com/forum/wiremod-addons/4708-wired-xyz-beacon-eject-input-socket.html

Wire Advanced Entity Marker - Divran
http://www.wiremod.com/forum/wiremod-lua-coding/18875-release-adv-entity-marker-holographic-text-screen.html

Multi Exit Point Controller
http://www.wiremod.com/forum/wiremod-lua-coding/18914-release-multi-exit-point-controller.html
